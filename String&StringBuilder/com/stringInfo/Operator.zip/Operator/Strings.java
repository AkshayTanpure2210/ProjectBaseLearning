package com.stringInfo.Operator;
import java.util.*;
import java.lang.String;

public class Strings /*{
public static void main(String[] args) {
    
{
 // concatenation = tow diffrent string converted into one string 
// example 1

String name1 = "Akshay";

String name2 ="Tanpure";


String fullname = name1 + name2;
System.out.println(fullname);
System.out.println(fullname.length());   
//  .length() we can use this method for masure length of string 

//use charAt for every char value present in string

for(int i =0; i <fullname.length(); i++)
{   System.out.println();
    System.out.println("next char :"+fullname.charAt(i));
    
}



// compare 

System.out.println("Example on CompareTo()");
String team = "India";
String team2= "india";
String team3= "India";
   if (team.compareTo(team2)==0)
      {
        System.out.println("string are equal");
      }
  else 
      {
        System.out.println("string are not equal");
      }

        System.out.println(" 2nd example ");

   if (team.compareTo(team3)==0)
     {
        System.out.println("string are equal");
     }
  else 
     {
        System.out.println("string are not equal");
     }


//same problem in == 
// why we consider compareTo method in String comparison and why we can not using == in String comparision

if(new String("India")==new String("India"))
  
  System.out.println("teams name is equal ");

   else 
   {
      System.out.println(" teams name is not equal");
   }

System.out.println(" from above result we can understand for String comparision CompareTo() is suitable");




// Substring - if string is long / short and we want to specific part of that string that time we can use this substring concept


String motivationnalQouets="A year from now you will wish you had started today.";

String line =motivationnalQouets.substring(6, motivationnalQouets.length());
String word = motivationnalQouets.substring(2,6);
String line1 = motivationnalQouets.substring(1);
System.out.println(line); // here we use starting index and .length method
System.out.println("acess word : "+ word);
System.out.println(line1); // here we give only starting index 



*/








































































}
}
}                                                                               


